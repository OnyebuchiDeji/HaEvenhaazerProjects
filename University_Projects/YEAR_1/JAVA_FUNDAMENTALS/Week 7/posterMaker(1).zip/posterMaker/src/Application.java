public class Application
{
    public static void main(String[] args)
    {
        Poster myPoster = new Poster();  // Create new poster.

        float red, green, blue;
        
        
        // Paint poster.

        red = 1.0F;
        green = 0.0F;
        blue = 0.0F;
        myPoster.setTileColour(0, 0, red, green, blue);

        red = 0.0F;
        green = 1.0F;
        blue = 0.0F;
        myPoster.setTileColour(0, 1, red, green, blue);
        
        red = 0.0F;
        green = 0.0F;
        blue = 1.0F;
        myPoster.setTileColour(1, 0, red, green, blue);

        
        myPoster.displayAndSave();  // Display the image and write to file.
    }
}
