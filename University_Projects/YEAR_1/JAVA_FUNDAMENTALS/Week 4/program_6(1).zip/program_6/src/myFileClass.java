import java.io.*;

public class myFileClass
{
    String fileName = null;

    public void createNewFile()
    {
        File fileObj = new File(fileName);

        try {
            if(fileObj.exists()) {
                System.out.println("Existing file \'" + fileName + "\' will be overwritten.");
            }
            PrintWriter fh = new PrintWriter(new FileWriter(fileName, false));
            fh.close();
        } catch (IOException e) {
            System.out.println("An IO Exception was thrown!\nMore details:\n" + e.toString());
        }
    }
    
    
    public void appendText(String lineText)
    {
        File fileObj = new File(fileName);
        
        if(fileObj.exists()) {
            try {
                PrintWriter fh = new PrintWriter(new FileWriter(fileName, true));
                fh.print(lineText);
                fh.close();
            } catch (IOException e) {
                System.out.println("An IO Exception was thrown!\nMore details:\n" + e.toString());
            }
        } else {
            System.out.println("File \'" + fileName + "\' does not exist!");
            System.exit(0);
        }
    }
    
    
    public String readLine(int lineNumber)
    {
        String lineText = null;
        File fileObj = new File(fileName);
        
        if(fileObj.exists()) {
            try {
                BufferedReader fh = new BufferedReader(new FileReader(fileName));

                boolean endOfFile = false;
                int lineCount = 0;

                while(!endOfFile) {
                    lineText = fh.readLine();

                    if(lineText == null) {
                        endOfFile = true;
                    } else if(lineCount == lineNumber) {
                        break;
                    } else {
                        lineCount++;
                    }
                }

                fh.close();

            } catch (IOException e) {
                System.out.println("An IO Exception was thrown!\nMore details:\n" + e.toString());
            }
        } else {
            System.out.println("File \'" + fileName + "\' does not exist!");
            System.exit(0);
        }

        return lineText;  // Will be null if end of file was reached.
    }

    
    public void displayContents()
    {
        File fileObj = new File(fileName);
        
        if(fileObj.exists()) {
            try {
                BufferedReader fh = new BufferedReader(new FileReader(fileName));

                boolean endOfFile = false;
                int lineCount = 0;

                while(!endOfFile) {
                    String line = fh.readLine();
                    if(line == null) {
                        endOfFile = true;
                    } else {
                        System.out.println(lineCount + ": " + line);
                    }
                    lineCount++;
                }

                fh.close();
            } catch (IOException e) {
                System.out.println("An IO Exception was thrown!\nMore details:\n" + e.toString());
            }
        } else {
            System.out.println("File \'" + fileName + "\' does not exist!");
            System.exit(0);
        }
    }
}
