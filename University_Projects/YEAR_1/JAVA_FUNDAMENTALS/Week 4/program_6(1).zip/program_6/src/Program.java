public class Program
{
    public static void main(String[] args)
    {
        myFileClass myFile = new myFileClass();  // Creating an object/instance from class "File".

        myFile.fileName = "myData.txt";  // Initializing the filename attribute of the object with the name of the file to be created/accessed.
        
        myFile.createNewFile();  // Create a new (empty) file.
        
        // Adding some text to the file:
        myFile.appendText("Ministers will be forced to explain\nto MPs a pledge by the prime minister to make\ngas and electricity suppliers offer\ncustomers their lowest tariffs.");
        myFile.appendText("\n(Taken from: http://www.bbc.co.uk/news/uk-19986929 on 18/10/2012)");
        
        System.out.println("\n\n");
        myFile.displayContents();
        
        System.out.println("\nThe second line in the file reads:");
        System.out.println(myFile.readLine(2));
    }
}
