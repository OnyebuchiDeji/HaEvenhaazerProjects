/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Ebenezer Ayo-Meti - 22021699 - x7e30
 */

public class Main
{
    public static void main(String[] args)
    {
        wordGame wg = new wordGame();
        
        wg.gameStart("Good");
    }
}
